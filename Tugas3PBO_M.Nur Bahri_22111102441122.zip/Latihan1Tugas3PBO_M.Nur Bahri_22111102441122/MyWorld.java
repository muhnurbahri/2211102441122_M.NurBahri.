import greenfoot.*;

public class MyWorld extends World {
    public MyWorld() {
        super(800, 600, 1);
        prepare();
    }
    
    private void prepare() {
        // Menginisialisasi objek-objek di dunia
        Radio radio = new Radio();
        addObject(radio, 100, 100);
        
        Televisi televisi = new Televisi("Sony");
        addObject(televisi, 200, 200);
    }
    
    public void act() {
        // Implementasi perilaku dunia di setiap siklus aksi
    }
}