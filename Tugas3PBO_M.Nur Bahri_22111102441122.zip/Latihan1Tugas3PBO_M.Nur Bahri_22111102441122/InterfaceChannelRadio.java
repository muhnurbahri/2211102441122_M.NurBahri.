public interface InterfaceChannelRadio {
    public void gantiChannel(int c);
}