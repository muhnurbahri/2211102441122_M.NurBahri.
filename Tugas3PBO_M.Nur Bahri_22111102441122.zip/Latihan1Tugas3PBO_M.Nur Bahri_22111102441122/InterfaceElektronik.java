public interface InterfaceElektronik {
    public void on();
    public void off();
}