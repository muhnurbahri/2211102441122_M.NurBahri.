import greenfoot.*;

public class MobilNegara extends Mobil {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada mobil negara
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada mobil negara
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada mobil negara
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}