import greenfoot.*;

public class MobilTransportasi extends Mobil {
    private int jmlKursi;
    
    public MobilTransportasi(int jmlKursi) {
        this.jmlKursi = jmlKursi;
    }
    
    public void tambahPenumpang() {
        // Implementasi penambahan penumpang pada mobil transportasi
    }
}