import greenfoot.*;

public class Ambulance extends MobilNegara {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada ambulance
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada ambulance
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada ambulance
    }
    
    public void nyalakanSirine() {
        // Implementasi untuk menyalakan sirine pada ambulance
    }
    
    public void matikanSirine() {
        // Implementasi untuk mematikan sirine pada ambulance
    }
    
    public void gantiSirine(int jenis) {
        // Implementasi untuk mengganti jenis sirine pada ambulance
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}