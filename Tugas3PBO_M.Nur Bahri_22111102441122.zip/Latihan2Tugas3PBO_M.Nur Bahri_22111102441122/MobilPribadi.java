import greenfoot.*;

public class MobilPribadi extends Mobil {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada mobil pribadi
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada mobil pribadi
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada mobil pribadi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}