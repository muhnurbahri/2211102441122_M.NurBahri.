import greenfoot.*;

public class Bus extends MobilPribadi {
    public void nyalakanTape() {
        // Implementasi untuk menyalakan tape pada bus
    }
    
    public void nyalakanTV() {
        // Implementasi untuk menyalakan TV pada bus
    }
    
    public void nyalakanAC() {
        // Implementasi untuk menyalakan AC pada bus
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}