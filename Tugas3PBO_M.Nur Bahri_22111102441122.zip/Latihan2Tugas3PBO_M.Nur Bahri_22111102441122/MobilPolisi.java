import greenfoot.*;

public class MobilPolisi extends MobilNegara {
    public void nyalakanSirine() {
        // Implementasi untuk menyalakan sirine pada mobil polisi
    }
    
    public void matikanSirine() {
        // Implementasi untuk mematikan sirine pada mobil polisi
    }
    
    public void gantiSirine(int jenis) {
        // Implementasi untuk mengganti jenis sirine pada mobil polisi
    }
    
    public void nyalakanRadioHT() {
        // Implementasi untuk menyalakan radio HT pada mobil polisi
    }
    
    public void matikanRadioHT() {
        // Implementasi untuk mematikan radio HT pada mobil polisi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}